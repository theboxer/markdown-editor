<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 John Peca

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '## Why Markdown

Content, and content marketing, is critical today. Sometimes, though, the systems to create content get in the way, overwhelming users and offering too many options. 

Simple, intuitive tools like _Markdown Editor_ can make it easier to focus—to create sharp copy and to consistently use images and rich media. 

The [core philosophy of Markdown](http://daringfireball.net/projects/markdown/syntax#philosophy) is focused on ease of use: be as easy-to-read and easy-to-write as feasible. If you have mastered web surfing, can type, and know how to copy/paste links to websites, you possess the technical skills you need to use _Markdown Editor_. 

## How Markdown Editor Works

_Markdown Editor_ is a MODX Extra for creating content with [Markdown](http://daringfireball.net/projects/markdown/syntax). It parses Markdown-formatted text into HTML, and stores it as content for MODX websites.

_Markdown Editor_ is great for creating articles, quick blogs, instructions, lists, and any other articles that require writing. It is also great for more technical documents like code tutorials because it supports [Github Flavored Markdown](https://help.github.com/articles/github-flavored-markdown/), or “GFM”.

_Markdown Editor_ also supports embedding content from other sites just by inserting a simple link. No complex HTML or JavaScript code to deal with. To do this, it uses a technology called [oEmbed](http://www.oembed.com/). Inserting a simple link to sites like Twitter, Tumblr, MonoPrice, Amazon, Flickr, Vimeo, Youtube, Evernote, and dozens of more sites results in a beautifully formatted synopis “card” and link to those sites or images.

## Requirements
_Markdown Editor_ requires 

- MODX Revolution 2.3+
- PHP 5.4+

## Features
- Live preview
- Drag & drop upload
- Image cropper
- Full screen focused writing mode
- oEmbed through multiple services
- Resource suggestion on ctrl+space
- Parsing MODX tag in live preview
- Custom CSS for Manager preview
- Auto include GFM & Highlight on frontend

## Background
_Markdown Editor_ uses several libraries to deliver an amazing experience when editing Markdown content.

_Markdown Editor_ itself is build on top of the great JavaScript editor [Ace](http://ace.c9.io/). It uses a customized version of Ace’s Markdown mode to improve working with the Markdown content. It also has enhanced list support, drag & drop upload, and more.

When creating content, you can quickly insert a link based on MODX Resource page titles by pressing `cmd/ctrl` + `space`. This will show a list of matching pages below your cursor based on the next characters you type. Use the arrow keys and the enter key or mouse and click to choose the page. It will insert a properly formatted link to that page using the correct Markdown and MODX syntax.

For transforming markdown into HTML, _Markdown Editor_ uses the [Remarkable](https://github.com/jonschlinkert/remarkable) JavaScript library with a support for GFM. Remarkable transforms makrdown to HTML blazingly fast, so you can enjoy real live preview.

- [Ace Editor](http://ace.c9.io/)
- [Remarkable](https://github.com/jonschlinkert/remarkable)
- [Cropper](https://github.com/fengyuanchen/cropper)
- [DiffDOM](https://github.com/fiduswriter/diffDOM)

## Contribution
I would love to thank [Roman](https://twitter.com/@renekopcem) & [Ryan](https://twitter.com/@rthrash) for providing unmeasurable support, amazing ideas and for helping with styling the editor.

### All contributors
- [Roman Klos](https://twitter.com/@renekopcem)
- [Ryan Thrash](https://twitter.com/@rthrash)

## Show Your Support
If you enjoy using Markdown Editor, please consider supporting its ongoing development or showing thanks via [PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FE62UABYW2V6S). 
Anything is appreciated!',
    'changelog' => '## MarkdownEditor 1.0.0

- Live preview
- Drag & drop upload
- Image cropper
- Resource suggestion on ctrl+space
- Parsing MODX tag in live preview
- Custom CSS for Manager preview
- Auto include GFM & Highlight on frontend',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4d54f5ef8842bf1501d78db7f39a29f6',
      'native_key' => 'markdowneditor',
      'filename' => 'modNamespace/d210c2dd5543e8e79ee9b71d97e2a308.vehicle',
      'namespace' => 'markdowneditor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '136ce906d5997e276cebbf9de5947d8d',
      'native_key' => 'markdowneditor.lp.parse_modx_tags',
      'filename' => 'modSystemSetting/9aae1e0694def143ab3b8e43ca88676b.vehicle',
      'namespace' => 'markdowneditor',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af211ecab975b276e779e23937acc8be',
      'native_key' => 'markdowneditor.lp.parse_modx_tags_timeout',
      'filename' => 'modSystemSetting/383479e8354f3433f8fe78ef8d4ca26d.vehicle',
      'namespace' => 'markdowneditor',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a3be8be6c793a7868e546c43cd14376',
      'native_key' => 'markdowneditor.upload.image_upload_path',
      'filename' => 'modSystemSetting/134aad7ebcfa2a9f8c3a04166ac64054.vehicle',
      'namespace' => 'markdowneditor',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86255b622ebd7101e8a887f12786dfcf',
      'native_key' => 'markdowneditor.upload.image_upload_url',
      'filename' => 'modSystemSetting/33ca75304004ebf2cafd478c3a5be048.vehicle',
      'namespace' => 'markdowneditor',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '214de49f9437127180e29830f5ad35c9',
      'native_key' => 'markdowneditor.upload.file_upload_path',
      'filename' => 'modSystemSetting/ffd1606009f66de74bb9ede460da6478.vehicle',
      'namespace' => 'markdowneditor',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bcb2ec382a11edb3d516e2701546e34',
      'native_key' => 'markdowneditor.upload.file_upload_url',
      'filename' => 'modSystemSetting/3b699520d630658e9df77154a6c50796.vehicle',
      'namespace' => 'markdowneditor',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5c95b82bde0697738417026148547b0',
      'native_key' => 'markdowneditor.upload.under_resource',
      'filename' => 'modSystemSetting/9d0d0d6852a506e811a18fcdc3e517bb.vehicle',
      'namespace' => 'markdowneditor',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '255daa85e7a1fc447aebddb9e9911e21',
      'native_key' => 'markdowneditor.upload.delete_unused',
      'filename' => 'modSystemSetting/134212fc35ee02282bf12c3fbb9dea73.vehicle',
      'namespace' => 'markdowneditor',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e29ce3d97675cd36f30dea39b2aa6e3',
      'native_key' => 'markdowneditor.upload.enable_image_upload',
      'filename' => 'modSystemSetting/96a5869f6cc26f206962f48cdc97b8f2.vehicle',
      'namespace' => 'markdowneditor',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '749f8c963915bbebdffc1f8fcbb7df72',
      'native_key' => 'markdowneditor.upload.enable_file_upload',
      'filename' => 'modSystemSetting/889bde1cb963428fb533a924a93b0cff.vehicle',
      'namespace' => 'markdowneditor',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b3a5a9a778a9dbab6fbcd4802fda11',
      'native_key' => 'markdowneditor.upload.max_size',
      'filename' => 'modSystemSetting/c9c13edf0f9bbbee4ae1e1d5d328acd4.vehicle',
      'namespace' => 'markdowneditor',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed32e4ec697caabd8b016aea4a4393a3',
      'native_key' => 'markdowneditor.upload.image_types',
      'filename' => 'modSystemSetting/e4613ce1a0bd9c42405e1aae1ded2559.vehicle',
      'namespace' => 'markdowneditor',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fe3a2fd816f9ea8e26ac90d8f8023f4',
      'native_key' => 'markdowneditor.upload.file_types',
      'filename' => 'modSystemSetting/b8d6f377ded1d8b7f18baef42e96737e.vehicle',
      'namespace' => 'markdowneditor',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '124b0da6c8ac37229dc2aa959e408f82',
      'native_key' => 'markdowneditor.cropper.enable_cropper',
      'filename' => 'modSystemSetting/e197c51c5ba9dc3802406e567aefaa13.vehicle',
      'namespace' => 'markdowneditor',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68d030b91c7f70656f9fc1977b81dda9',
      'native_key' => 'markdowneditor.cropper.show_description',
      'filename' => 'modSystemSetting/54368fb926c2d3cfee28c18d9ba1aa40.vehicle',
      'namespace' => 'markdowneditor',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468b373c8d8ca0c3ac68e871ec69f895',
      'native_key' => 'markdowneditor.cropper.profiles',
      'filename' => 'modSystemSetting/d0761e7aee60d00d8d01cb75020d1797.vehicle',
      'namespace' => 'markdowneditor',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '552c19d01321d1967a0cfa3e2a413837',
      'native_key' => 'markdowneditor.resizer.aspect_ratio_constraint',
      'filename' => 'modSystemSetting/a0d08fbc27de24e54aa1ad09a8ff062a.vehicle',
      'namespace' => 'markdowneditor',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad26f7a327b2e630d3cd5659cdaebb1d',
      'native_key' => 'markdowneditor.resizer.upsize_constraint',
      'filename' => 'modSystemSetting/40f941d0aae03071f045829aac35cfec.vehicle',
      'namespace' => 'markdowneditor',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09c69813e3ce64b350ebeea81c4b9ef9',
      'native_key' => 'markdowneditor.resizer.width',
      'filename' => 'modSystemSetting/92c1812652f4e03f7ead8691ad4222b1.vehicle',
      'namespace' => 'markdowneditor',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01756ea62e469097f5f6ecc31c4a3e62',
      'native_key' => 'markdowneditor.resizer.height',
      'filename' => 'modSystemSetting/41e4d198d324b8f682a9966710b52f68.vehicle',
      'namespace' => 'markdowneditor',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f6ee97bb5a0a32f1f4e385237db16ec',
      'native_key' => 'markdowneditor.general.theme',
      'filename' => 'modSystemSetting/d86d544157a1debaded9fe7798c48253.vehicle',
      'namespace' => 'markdowneditor',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a68649ac9124ad2efd20ed5308cc86c1',
      'native_key' => 'markdowneditor.general.font_size',
      'filename' => 'modSystemSetting/0b7b31044e01430fa6129ca3484833fd.vehicle',
      'namespace' => 'markdowneditor',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83fd21ed00ab93841d0d4e619df6e7b2',
      'native_key' => 'markdowneditor.general.font_family',
      'filename' => 'modSystemSetting/89cdc5596f9dbf470736f46e01832093.vehicle',
      'namespace' => 'markdowneditor',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bde8b9c7cdc8cde90b46a1a80a1ca419',
      'native_key' => 'markdowneditor.general.include_ghfmd',
      'filename' => 'modSystemSetting/e5bbb91da0201238304f2de38fe579f9.vehicle',
      'namespace' => 'markdowneditor',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eff87cc66662a4514f671479cfa7c70c',
      'native_key' => 'markdowneditor.general.include_ghfmd_manager',
      'filename' => 'modSystemSetting/28dd3b504c3a5df9ee92c4dbb3e0f9f2.vehicle',
      'namespace' => 'markdowneditor',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c70b915e9a3d8d209563320ae187420c',
      'native_key' => 'markdowneditor.general.custom_css_manager',
      'filename' => 'modSystemSetting/52a94276adae2837126da3f5648c729d.vehicle',
      'namespace' => 'markdowneditor',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25a5efdce1275e93e94d2a8d533a8e18',
      'native_key' => 'markdowneditor.general.include_highlight',
      'filename' => 'modSystemSetting/1fd704333e44aa149f375ecb20778619.vehicle',
      'namespace' => 'markdowneditor',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c128ff236b04c1b4eec80f6b318ae920',
      'native_key' => 'markdowneditor.general.split',
      'filename' => 'modSystemSetting/9f0c26f2a5961829a010102fcbcc04a0.vehicle',
      'namespace' => 'markdowneditor',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4820d87ebe17e0785e9fc18227a857d5',
      'native_key' => 'markdowneditor.general.split_fullscreen',
      'filename' => 'modSystemSetting/e2189acc96cf539f71d3ca06cb551503.vehicle',
      'namespace' => 'markdowneditor',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a458ab7640ecd5b1a43496f5a63fef22',
      'native_key' => 'markdowneditor.general.source',
      'filename' => 'modSystemSetting/f696cf25c511fdad4592fa0d1f8c6999.vehicle',
      'namespace' => 'markdowneditor',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c46917dcb0907bbc8f90f77eee3400d7',
      'native_key' => 'markdowneditor.general.source_select',
      'filename' => 'modSystemSetting/928382c41067aab88cc362633ad36537.vehicle',
      'namespace' => 'markdowneditor',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6aeab39527138036fcfecf347e7458ea',
      'native_key' => 'markdowneditor.oembed.service',
      'filename' => 'modSystemSetting/035d0f26e63b05ca8cfaae973df42452.vehicle',
      'namespace' => 'markdowneditor',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11d66ad58cd1d9bc04b7870b08a9fd34',
      'native_key' => 'markdowneditor.oembed.max_height',
      'filename' => 'modSystemSetting/7f623cf95e07e5a58c385994cc67503e.vehicle',
      'namespace' => 'markdowneditor',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d8174af036b9086c53496cae8005aaf',
      'native_key' => 'markdowneditor.oembed.max_width',
      'filename' => 'modSystemSetting/ae9e6f1d5ca3659aca2af221cbd7b5e0.vehicle',
      'namespace' => 'markdowneditor',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b4c8b49119889069c9bc6b60353b2b2',
      'native_key' => 'markdowneditor.oembed.frontend_css',
      'filename' => 'modSystemSetting/253e98e2146eb4e52b35569e22ce1d2f.vehicle',
      'namespace' => 'markdowneditor',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce2368287bbf4cb2d05dd67d1c219af1',
      'native_key' => 'markdowneditor.oembed.default_card_color',
      'filename' => 'modSystemSetting/d21addfde01f6615a6ec9db1561d09b5.vehicle',
      'namespace' => 'markdowneditor',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25f2a98e22d40c176593711a429b4496',
      'native_key' => 'markdowneditor.oembed.auto_card_color',
      'filename' => 'modSystemSetting/57d5b39cd0e7f71e3ce17679d4521987.vehicle',
      'namespace' => 'markdowneditor',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40250c0fecfcf3687adc09f241112dab',
      'native_key' => 'markdowneditor.embedly.api_key',
      'filename' => 'modSystemSetting/d1584b61fe338ae4d4a816e44fce6c1a.vehicle',
      'namespace' => 'markdowneditor',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1a02734a4e086ce2c92c4c34f587a985',
      'native_key' => NULL,
      'filename' => 'modCategory/0a135d737c880f03813f06c62898edd1.vehicle',
      'namespace' => 'markdowneditor',
    ),
  ),
);