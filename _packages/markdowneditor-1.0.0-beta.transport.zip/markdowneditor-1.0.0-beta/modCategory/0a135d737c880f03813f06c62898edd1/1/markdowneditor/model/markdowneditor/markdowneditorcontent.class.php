<?php
/**
 * @property int $object_id
 * @property string $element_name
 * @property string $namespace
 * @property string $content
 *
 * @package markdowneditor
 */
class MarkdownEditorContent extends xPDOObject {}