<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2015 John Peca

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => '## Why Markdown

Content, and content marketing, is critical today. Sometimes, though, the systems to create content get in the way, overwhelming users and offering too many options. 

Simple, intuitive tools like _Markdown Editor_ can make it easier to focus—to create sharp copy and to consistently use images and rich media. 

The [core philosophy of Markdown](http://daringfireball.net/projects/markdown/syntax#philosophy) is focused on ease of use: be as easy-to-read and easy-to-write as feasible. If you have mastered web surfing, can type, and know how to copy/paste links to websites, you possess the technical skills you need to use _Markdown Editor_. 

## How Markdown Editor Works

_Markdown Editor_ is a MODX Extra for creating content with [Markdown](http://daringfireball.net/projects/markdown/syntax). It parses Markdown-formatted text into HTML, and stores it as content for MODX websites.

_Markdown Editor_ is great for creating articles, quick blogs, instructions, lists, and any other articles that require writing. It is also great for more technical documents like code tutorials because it supports [Github Flavored Markdown](https://help.github.com/articles/github-flavored-markdown/), or “GFM”.

_Markdown Editor_ also supports embedding content from other sites just by inserting a simple link. No complex HTML or JavaScript code to deal with. To do this, it uses a technology called [oEmbed](http://www.oembed.com/). Inserting a simple link to sites like Twitter, Tumblr, MonoPrice, Amazon, Flickr, Vimeo, Youtube, Evernote, and dozens of more sites results in a beautifully formatted synopis “card” and link to those sites or images.

## Requirements
_Markdown Editor_ requires 

- MODX Revolution 2.3+
- PHP 5.4+

## Features
- Live preview
- Drag & drop upload
- Image cropper
- Full screen focused writing mode
- oEmbed through multiple services
- Resource suggestion on ctrl+space
- Parsing MODX tag in live preview
- Custom CSS for Manager preview
- Auto include GFM & Highlight on frontend

## Background
_Markdown Editor_ uses several libraries to deliver an amazing experience when editing Markdown content.

_Markdown Editor_ itself is build on top of the great JavaScript editor [Ace](http://ace.c9.io/). It uses a customized version of Ace’s Markdown mode to improve working with the Markdown content. It also has enhanced list support, drag & drop upload, and more.

When creating content, you can quickly insert a link based on MODX Resource page titles by pressing `cmd/ctrl` + `space`. This will show a list of matching pages below your cursor based on the next characters you type. Use the arrow keys and the enter key or mouse and click to choose the page. It will insert a properly formatted link to that page using the correct Markdown and MODX syntax.

For transforming markdown into HTML, _Markdown Editor_ uses the [Remarkable](https://github.com/jonschlinkert/remarkable) JavaScript library with a support for GFM. Remarkable transforms makrdown to HTML blazingly fast, so you can enjoy real live preview.

- [Ace Editor](http://ace.c9.io/)
- [Remarkable](https://github.com/jonschlinkert/remarkable)
- [Cropper](https://github.com/fengyuanchen/cropper)
- [DiffDOM](https://github.com/fiduswriter/diffDOM)

## Contribution
I would love to thank [Roman](https://twitter.com/@renekopcem) & [Ryan](https://twitter.com/@rthrash) for providing unmeasurable support, amazing ideas and for helping with styling the editor.

### Contributors
- [Roman Klos](https://twitter.com/@renekopcem)
- [Ryan Thrash](https://twitter.com/@rthrash)
- [All contributors](https://github.com/TheBoxer/markdown-editor/graphs/contributors)

## Show Your Support
If you enjoy using Markdown Editor, please consider supporting its ongoing development or showing thanks via [PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=FE62UABYW2V6S). 
Anything is appreciated!',
    'changelog' => '## MarkdownEditor 1.0.0

- Live preview
- Drag & drop upload
- Image cropper
- Resource suggestion on ctrl+space
- Parsing MODX tag in live preview
- Custom CSS for Manager preview
- Auto include GFM & Highlight on frontend',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '587b46abeb4a247dd5cc720715304825',
      'native_key' => 'markdowneditor',
      'filename' => 'modNamespace/1f313d847601c04cea233b938ff256bf.vehicle',
      'namespace' => 'markdowneditor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a18728db28b679da006f631eaeb3037',
      'native_key' => 'markdowneditor.lp.parse_modx_tags',
      'filename' => 'modSystemSetting/c9d7d44c973d8216562971a4224a8c33.vehicle',
      'namespace' => 'markdowneditor',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0841fc5ad920472a439e7d182db60ad1',
      'native_key' => 'markdowneditor.lp.parse_modx_tags_timeout',
      'filename' => 'modSystemSetting/f0f3d9ae7a0cff9a25b877efab2df9cb.vehicle',
      'namespace' => 'markdowneditor',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c0ad2e3b5c2e3a7017dccfbb0657166',
      'native_key' => 'markdowneditor.upload.image_upload_path',
      'filename' => 'modSystemSetting/c53a14bc6a2c776f26c93d69449af113.vehicle',
      'namespace' => 'markdowneditor',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68846e1827e1a1f1eaf2815add728998',
      'native_key' => 'markdowneditor.upload.image_upload_url',
      'filename' => 'modSystemSetting/71a3bc2f2417851dcbccbf70c04f381d.vehicle',
      'namespace' => 'markdowneditor',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dce5d831254ed8e34ed7874267bd459',
      'native_key' => 'markdowneditor.upload.file_upload_path',
      'filename' => 'modSystemSetting/454584463316ffe47660bbf3094749a2.vehicle',
      'namespace' => 'markdowneditor',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b2deb328494d64de94883cb4713dbe2',
      'native_key' => 'markdowneditor.upload.file_upload_url',
      'filename' => 'modSystemSetting/2481160350605fb5db6bbecf4fe51103.vehicle',
      'namespace' => 'markdowneditor',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '357783d1cd639b6b233cecbc1f143ef3',
      'native_key' => 'markdowneditor.upload.under_resource',
      'filename' => 'modSystemSetting/d6b2cfc13fd5e2519e6d021eb543a095.vehicle',
      'namespace' => 'markdowneditor',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e86d4ef9f69aa6009369a3b323b11f9',
      'native_key' => 'markdowneditor.upload.delete_unused',
      'filename' => 'modSystemSetting/a2dfc423ad8b3efab387491aea75a8cf.vehicle',
      'namespace' => 'markdowneditor',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfacfd861bbf9417e3fe4b5b4e333b79',
      'native_key' => 'markdowneditor.upload.enable_image_upload',
      'filename' => 'modSystemSetting/8b22f11cc831166c20b5260c850422f9.vehicle',
      'namespace' => 'markdowneditor',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '599aa847f96fd9182a96db160ae69613',
      'native_key' => 'markdowneditor.upload.enable_file_upload',
      'filename' => 'modSystemSetting/6d335e405152b36f06716f2a514eb963.vehicle',
      'namespace' => 'markdowneditor',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f837c4bf29d286dfc82eb86b85f52fc',
      'native_key' => 'markdowneditor.upload.max_size',
      'filename' => 'modSystemSetting/e71c959c240e46031896ff9d983f98b3.vehicle',
      'namespace' => 'markdowneditor',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c21c9b9a6ef467a1393a8455e5b1c2d9',
      'native_key' => 'markdowneditor.upload.image_types',
      'filename' => 'modSystemSetting/e29ceee70b236b82631206ff0a74f68b.vehicle',
      'namespace' => 'markdowneditor',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0750afc8aee70534839180d700b17cd9',
      'native_key' => 'markdowneditor.upload.file_types',
      'filename' => 'modSystemSetting/d8ecfdbe13dea16aa0b2616eab9fb4cd.vehicle',
      'namespace' => 'markdowneditor',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26f8ff7b2d73e12698871d2b22ef0c64',
      'native_key' => 'markdowneditor.cropper.enable_cropper',
      'filename' => 'modSystemSetting/7d4910188b2b3b1852872999712569f1.vehicle',
      'namespace' => 'markdowneditor',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82f542a044f6894295652947840c5d15',
      'native_key' => 'markdowneditor.cropper.show_description',
      'filename' => 'modSystemSetting/87d6de8754d21e533fc66b0879d55a87.vehicle',
      'namespace' => 'markdowneditor',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b889d84a10a01a2ff15dddfbd6190781',
      'native_key' => 'markdowneditor.cropper.profiles',
      'filename' => 'modSystemSetting/53fd00f64bf00aadcc41274db1bf4742.vehicle',
      'namespace' => 'markdowneditor',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4f0bdb414be9c8548749fcf95583fb2',
      'native_key' => 'markdowneditor.resizer.aspect_ratio_constraint',
      'filename' => 'modSystemSetting/45c1096c0b1a90d4bbde98e5b08d5a3a.vehicle',
      'namespace' => 'markdowneditor',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd21aaab9de2e653199fe5c5b4d14139c',
      'native_key' => 'markdowneditor.resizer.upsize_constraint',
      'filename' => 'modSystemSetting/a675769f3b777aaa21cb647ef6ddd829.vehicle',
      'namespace' => 'markdowneditor',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96490e5663ed5bfca99afc8c6d93723f',
      'native_key' => 'markdowneditor.resizer.width',
      'filename' => 'modSystemSetting/ddaf751ed6da21425d11548f75f6a70f.vehicle',
      'namespace' => 'markdowneditor',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a41354c31c53dfa5fa6c4356679f3983',
      'native_key' => 'markdowneditor.resizer.height',
      'filename' => 'modSystemSetting/1154cef14a477ca8391b4651907286ec.vehicle',
      'namespace' => 'markdowneditor',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5f7d48a34ba51238aee8ccd5272f097',
      'native_key' => 'markdowneditor.general.theme',
      'filename' => 'modSystemSetting/f707935d8f2124c3bcca63d9f128a625.vehicle',
      'namespace' => 'markdowneditor',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ce4bc2e6b14c57b494b8826a1ad09c8',
      'native_key' => 'markdowneditor.general.font_size',
      'filename' => 'modSystemSetting/00d917e217f579111c9b942b4bee508f.vehicle',
      'namespace' => 'markdowneditor',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f96d2468b525ebf487a40c9f6339dd44',
      'native_key' => 'markdowneditor.general.font_family',
      'filename' => 'modSystemSetting/61e6c7e5257494251ccd395b28db1bb3.vehicle',
      'namespace' => 'markdowneditor',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '079c06957badd17455b02d0023c88ef5',
      'native_key' => 'markdowneditor.general.include_ghfmd',
      'filename' => 'modSystemSetting/f11bbf0e63cc3834d0196fe06a8ad502.vehicle',
      'namespace' => 'markdowneditor',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a51ac6d06426219b37a001c5ff85967',
      'native_key' => 'markdowneditor.general.include_ghfmd_manager',
      'filename' => 'modSystemSetting/89e2a9c2dd365650d4baf80faecab588.vehicle',
      'namespace' => 'markdowneditor',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c57141a470758eb05e46190098784052',
      'native_key' => 'markdowneditor.general.custom_css_manager',
      'filename' => 'modSystemSetting/7067cc3cf28609a6af4d50aedf9005c7.vehicle',
      'namespace' => 'markdowneditor',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0332f11a34bd8a5f4c578c638e0703cc',
      'native_key' => 'markdowneditor.general.include_highlight',
      'filename' => 'modSystemSetting/2ba80b246384582c63f19051ac698289.vehicle',
      'namespace' => 'markdowneditor',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '515ba2ec45f13f0a30f143c3d089b43f',
      'native_key' => 'markdowneditor.general.split',
      'filename' => 'modSystemSetting/247c16cf9e715dc88de09e13e0e2280b.vehicle',
      'namespace' => 'markdowneditor',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30347dc4bd70aee5eff9ed77a192239e',
      'native_key' => 'markdowneditor.general.split_fullscreen',
      'filename' => 'modSystemSetting/aa0d1ca56c6f87eaba1f125ef26cb108.vehicle',
      'namespace' => 'markdowneditor',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '047fd1ab8c5ff10bc528f102c5da74a7',
      'native_key' => 'markdowneditor.general.source',
      'filename' => 'modSystemSetting/6e0cca55fcea554952005de8eb71ce51.vehicle',
      'namespace' => 'markdowneditor',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e811605cedc89bc715a44f32f39632d7',
      'native_key' => 'markdowneditor.general.source_select',
      'filename' => 'modSystemSetting/143bafbdaed6ff703b59e003383611de.vehicle',
      'namespace' => 'markdowneditor',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '397a141d2f1a63aa970860a4084a18a8',
      'native_key' => 'markdowneditor.oembed.service',
      'filename' => 'modSystemSetting/430dad47698a5e6a31c24e619ba04c44.vehicle',
      'namespace' => 'markdowneditor',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27050f0defcda0e16ede6f5c5dff106c',
      'native_key' => 'markdowneditor.oembed.max_height',
      'filename' => 'modSystemSetting/5ca80d8867a90a2a6cfa210409bbc947.vehicle',
      'namespace' => 'markdowneditor',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '648bbf713ffb718d03a898400326a31e',
      'native_key' => 'markdowneditor.oembed.max_width',
      'filename' => 'modSystemSetting/9d79e4d5cbffbdd4b10d49afad130d4e.vehicle',
      'namespace' => 'markdowneditor',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c52baaceafc6e77dce6654c519f41261',
      'native_key' => 'markdowneditor.oembed.frontend_css',
      'filename' => 'modSystemSetting/8452ed826e3e761022c43f32be8d57a0.vehicle',
      'namespace' => 'markdowneditor',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '485a56a8914b0ca45a689f5f2d08b89c',
      'native_key' => 'markdowneditor.oembed.default_card_color',
      'filename' => 'modSystemSetting/1dbf6d58305b62a8c3deb0c190184076.vehicle',
      'namespace' => 'markdowneditor',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd9eb51dd1caaff3d5acff330d31a410',
      'native_key' => 'markdowneditor.oembed.auto_card_color',
      'filename' => 'modSystemSetting/e8b2946251200edd36b4afe405eadabf.vehicle',
      'namespace' => 'markdowneditor',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd2bb590e90f21998ed61c02e650fb97',
      'native_key' => 'markdowneditor.embedly.api_key',
      'filename' => 'modSystemSetting/da92558f3fa266ad4018f59dc7839360.vehicle',
      'namespace' => 'markdowneditor',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1ee47e0e36a62dddaa3de9a047f41d12',
      'native_key' => NULL,
      'filename' => 'modCategory/cd08872c67cbf5e020fde98795019309.vehicle',
      'namespace' => 'markdowneditor',
    ),
  ),
);